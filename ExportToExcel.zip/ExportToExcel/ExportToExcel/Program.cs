﻿using ExportToExcel.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExportToExcel
{
    class Program
    {
        static void Main(string[] args)
        {

            ExportExcelDb db = new ExportExcelDb();
            List<Vendor> vendors = db.Vendors.ToList();
            ExportFromListEntity.ExportToExcelFromListEntity<Vendor>(vendors, @"E:\Temp\ExportExcel", "Export from List Entity.xlsx");            

            Console.WriteLine("Done");
            Console.ReadLine();
        }
    }
}
