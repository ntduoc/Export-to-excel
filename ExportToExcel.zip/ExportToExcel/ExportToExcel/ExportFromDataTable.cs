﻿using System.Data;
using System.IO;
using Microsoft.Office.Interop.Excel;

namespace ExportToExcel
{
    public class ExportFromDataTable
    {
        public static void ExportToExcelFromDataTable(System.Data.DataTable dataTable, string exportPath,string filename)
        {
            DataSet dataSet = new DataSet();
            dataSet.Tables.Add(dataTable);

            // create a excel app along side with workbook and worksheet and give a name to it  
            Application excelApp = new Application();
            Workbook excelWorkBook = excelApp.Workbooks.Add();                   
            Worksheet excelWorkSheet = excelWorkBook.Sheets.Add();
            excelWorkSheet.Name = filename;
            // Make excel column from datattable columns
            for (int i = 1; i < dataTable.Columns.Count + 1; i++)
            {
                excelWorkSheet.Cells[1, i] = dataTable.Columns[i - 1].ColumnName;
            }
            // Make excel row from datatable row
            for (int j = 0; j < dataTable.Rows.Count; j++)
            {
                for (int k = 0; k < dataTable.Columns.Count; k++)
                {
                    excelWorkSheet.Cells[j + 2, k + 1] = dataTable.Rows[j].ItemArray[k].ToString();
                }
            }
            //Combine folder path and file name to save
            exportPath = Path.Combine(exportPath, filename);           
            excelWorkBook.SaveAs(exportPath);
            excelWorkBook.Close();
            excelApp.Quit();
        }
    }
}
