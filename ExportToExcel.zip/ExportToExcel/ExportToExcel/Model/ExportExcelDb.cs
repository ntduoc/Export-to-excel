using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace ExportToExcel.Model
{
    public partial class ExportExcelDb : DbContext
    {
        public ExportExcelDb()
            : base("name=ExportExcelDb")
        {
        }
        public virtual DbSet<Vendor> Vendors { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
    }
}
